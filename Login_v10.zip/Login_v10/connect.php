<?php
$dbserver = "localhost";
$dbuser = "asiantee_infor";
$dbpass = "Mailacong123";
$dbname = "asiantee_infor";
$connect = mysql_connect($dbserver,$dbuser,$dbpass,$dbname);
?>